#include <iostream>

int main()
{
  using namespace std;
  cout << "linuxconfig.org\n";
return 0;
}
