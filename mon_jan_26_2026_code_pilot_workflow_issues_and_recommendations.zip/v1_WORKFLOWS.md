# WebLabs-MobIDE Workflow Configuration

## Overview
This directory contains 100% functional CI/CD workflows for the WebLabs-MobIDE Android + WebIDE hybrid project.

## Workflow Breakdown

### Primary Workflows (Always Run)

| Workflow | Purpose | Trigger |
|----------|---------|---------|
| `01-setup-and-lint.yml` | Linting (Node.js, Python, Gradle) | Push to main/develop/WebOps, PRs |
| `02-build-android.yml` | Build Debug APK | Push to main/develop/WebOps, PRs |
| `03-android-compatibility.yml` | ARM64 compatibility verification | Push to main/develop/WebOps, PRs |
| `04-nodejs-tests.yml` | Node.js build + tests | Push to main/develop/WebOps, PRs |
| `05-codeql-security.yml` | CodeQL security scan (Java/JS/Python) | Push to main/develop, PRs, Weekly |
| `06-release-apk.yml` | Release/Debug APK builder | Manual dispatch |
| `07-compliance-check.yml` | Repository structure compliance | Push to main/develop, PRs |
| `08-pages-deploy.yml` | Deploy docs to GitHub Pages | Push to main |

### Supporting Workflows

| Workflow | Purpose | Status |
|----------|---------|--------|
| `ci.yml` | Legacy CI (kept for compatibility) | ✅ FUNCTIONAL |
| `build.yml` | Model vendoring + APK build | ✅ FUNCTIONAL (FIXED) |
| `codeql.yml` | Security scanning | ✅ FUNCTIONAL (FIXED) |
| `copilot-setup-steps.yml` | GitHub Copilot setup | ✅ FUNCTIONAL (FIXED) |
| `static.yml` | GitHub Pages deployment | ✅ FUNCTIONAL |

### Deprecated/Removed Workflows

| Workflow | Reason |
|----------|--------|
| `codepilot.yml` | ❌ BROKEN: Self-modifying workflow (security risk) |
| `codelite.yml` | ❌ BROKEN: Incomplete quantum logic |
| `codeyl.yml` | ❌ BROKEN: Malformed YAML |
| `compliance-enforcer.yml` | ❌ INCOMPLETE: Stub implementation |
| `ai-architect.yml` | ❌ UNUSED: File reorganization (risky) |
| `runtime-logs-creator.yml` | ⚠️ REDUNDANT: Replaced by artifact steps in other workflows |

## Configuration

All workflows use:
- **Java**: 17 (Temurin)
- **Node.js**: 20 LTS
- **Python**: 3.11
- **Android SDK**: API 34, NDK 25.2.9519653
- **Gradle**: ./gradlew (5.x+)

## Execution Order (Per Push)

1. **Parallel**: Lint (Node, Python, Gradle)
2. **Parallel**: Build APK, Node tests, Android compatibility check
3. **Parallel**: CodeQL scan, Compliance check
4. **Sequential**: Deploy to Pages (if all pass + main branch)

## Secrets Required

None explicitly required. All workflows use default GitHub Actions permissions.

Optional:
- `PAT_WORKFLOW_UPDATE` (if workflow auto-updates needed — NOT RECOMMENDED)

## Manual Workflows

**Release APK**:
```bash
gh workflow run 06-release-apk.yml \
  -f build_type=Release